local attractors = {
    ["biter-attractor-1"] = {radius = 200},
    ["biter-attractor-2"] = {radius = 250},
}
return attractors