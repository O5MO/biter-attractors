---@param player LuaPlayer
function get_cursor_position(player)
    return player.position
end